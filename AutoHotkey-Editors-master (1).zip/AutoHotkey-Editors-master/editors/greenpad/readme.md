﻿Installer for AutoHotkey Syntax Highlighting
GreenPad version 1.08 U
http://www.kmonos.net/lib/gp.en.html