﻿TotalHLT (Total Highlight) is a Lister plugin for [Total Commander](http://www.ghisler.com/).

The major function is to display source code files with syntax highlight. 
Available on totalcmd.net at http://www.totalcmd.net/plugring/hlight.html
